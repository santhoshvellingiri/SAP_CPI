import com.sap.gateway.ip.core.customdev.processor.MessageImpl;
import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.xml.XmlUtil;

def Message processData(Message message) {

	def body = message.getBody(java.io.Reader)
	def root = new XmlSlurper().parse(body)

	//Loop through each User Credentials
	root.UserCredential.each { UserCredential ->
		//Fetch the User Credentials Kind
		def kind = UserCredential.Kind.toString()
		//Check if it's non default or success factors type
		if(!(kind.equalsIgnoreCase("default") ||
		kind.equalsIgnoreCase("successfactors") || 
		kind.equalsIgnoreCase("openconnectors") || 
		kind.equalsIgnoreCase("secure_param") )) {
			//remove such user credentials node
			UserCredential.replaceNode {}
		}
	}

	message.setBody(XmlUtil.serialize(root));
	return message;
}