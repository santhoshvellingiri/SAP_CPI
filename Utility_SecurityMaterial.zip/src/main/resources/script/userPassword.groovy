import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;
import groovy.util.XmlSlurper;
import groovy.xml.XmlUtil;

def Message processData(Message message) {


	def service = ITApiFactory.getService(SecureStoreService.class, null);

	if( service != null) {
		def body = message.getBody(java.io.Reader);
		def root = new XmlSlurper().parse(body);

		String credName = root.UserCredential.Name.toString();
		String kind = root.UserCredential.Kind.toString();

		def credential = service.getUserCredential(credName);
		def pwd = credential.getPassword();

		if(!kind.equalsIgnoreCase("openconnectors"))
			root.UserCredential.Password.replaceBody pwd;
		else {
		    String value = new String(pwd);
		    root.UserCredential.User.replaceBody value.split(",")[0].split(" ")[1];
			root.UserCredential.appendNode{
				Organization(value.split(",")[1].trim().split(" ")[1]);
				Element(value.split(",")[2].trim().split(" ")[1]);
			}
			root.UserCredential.Password.replaceNode {};
		}
		root.UserCredential.SecurityArtifactDescriptor.replaceNode {};

		message.setBody(XmlUtil.serialize(root));
		return message;
	}
}