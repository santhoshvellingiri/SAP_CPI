import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.UserCredential;
import com.sap.it.api.securestore.exception.SecureStoreException;
import groovy.util.XmlSlurper;
import groovy.xml.XmlUtil;

def Message processData(Message message) {

	def service = ITApiFactory.getService(SecureStoreService.class, null);

	if( service != null) {
		def body = message.getBody(java.io.Reader);
		def root = new XmlSlurper().parse(body);

		String credName = root.OAuth2ClientCredential.Name.toString();

		def credential = service.getUserCredential(credName);
		def secret = credential.getPassword();

		root.OAuth2ClientCredential.ClientSecret.replaceBody secret;
		root.OAuth2ClientCredential.SecurityArtifactDescriptor.replaceNode {};

		message.setBody(XmlUtil.serialize(root));
		return message;
	}
}