import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.keystore.KeystoreService;
import java.security.cert.Certificate;
import java.security.Key;
import groovy.xml.XmlUtil;

def Message processData(Message message) {

	KeystoreService service = ITApiFactory.getService(KeystoreService.class, null);

	if( service != null) {
		def body = message.getBody(java.io.Reader);
		def root = new XmlSlurper().parse(body);

		String Alias = root.KeystoreEntry.Alias.toString();
		
		Key pKey = service.getKey(Alias);
		String pKeyB64Enc = new String(Base64.getEncoder().encode(pKey.getEncoded()));

        Certificate pCer = service.getCertificate(Alias);
		String pCerB64Enc = new String(Base64.getEncoder().encode(pCer.getEncoded()));	

		root.KeystoreEntry.appendNode{
			PrivateKey(pKeyB64Enc);
			PublicCertificate(pCerB64Enc);
		}

		message.setBody(XmlUtil.serialize(root));
		return message;
	}
}